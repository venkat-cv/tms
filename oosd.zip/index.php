<?php
echo '<script>location.href="login.php";</script>';
?>
