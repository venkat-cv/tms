<?php

echo "<script src='scripts/jquery.min.js'></script>";
echo "<script src='scripts/bootstrap.min.js'></script>";
echo "<link href='scripts/bootstrap.min.css' type='text/css' rel='stylesheet'/>";
echo "<link href='scripts/style.css' type='text/css' rel='stylesheet'/>";
echo "<script src='scripts/script.js'></script>";
echo "<link href='scripts/bootstrap-editable/css/bootstrap-editable.css' rel='stylesheet'>";
echo "<link href='scripts/datetime-picker.css' rel='stylesheet'>";
echo "<script src='scripts/bootstrap-datetime-picker.js'></script>";
echo "<script src='scripts/moment.js'></script>";
echo "<script src='scripts/bootstrap-editable/js/bootstrap-editable.js'></script>";

?>
